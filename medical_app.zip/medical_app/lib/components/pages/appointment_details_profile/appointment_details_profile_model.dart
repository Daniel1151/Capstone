import '/flutter_flow/flutter_flow_util.dart';
import 'appointment_details_profile_widget.dart'
    show AppointmentDetailsProfileWidget;
import 'package:flutter/material.dart';

class AppointmentDetailsProfileModel
    extends FlutterFlowModel<AppointmentDetailsProfileWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
